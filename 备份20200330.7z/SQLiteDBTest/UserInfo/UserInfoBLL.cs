﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
namespace BLL
{
    public partial class UserInfo
    {
        private readonly DAL.UserInfo dal = new DAL.UserInfo();
        public UserInfo()
        { }
        #region  BasicMethod
        /// <summary>
        /// 得到最大ID
        /// </summary>
        public int GetMaxId()
        {
            return dal.GetMaxId();
        }
        /// <summary>
        /// 查询ID是否存在该记录
        /// </summary>
        public bool Exists(int ID)
        {
            return dal.Exists(ID);
        }
        /// <summary>
        ///  查询数据库属性为字符串的字段是否存在记录内容（查重）
        /// </summary>
        /// <param name="_TxtSearch1">要查询的文本字</param>
        /// <param name="_ZR1_XX1">数据库字段名称</param>
        /// <returns></returns>
        public bool Exists_ZR1_XX1(string _TxtSearch1, string _ZR1_XX1)
        {
            return dal.Exists_ZR1_XX2(_TxtSearch1, _ZR1_XX1);
        }
        /// <summary>
        /// 增加一条数据
        /// </summary>
        public bool Add(Model.UserInfo model)
        {
            return dal.Add(model);
        }
        /// <summary>
        /// 更新一条数据
        /// </summary>
        public bool Update(Model.UserInfo model)
        {
            return dal.Update(model);
        }
        /// <summary>
        /// 删除一条数据
        /// </summary>
        public bool Delete(int ID)
        {
            return dal.Delete(ID);
        }
        /// <summary>
        /// 批量删除表数据
        /// </summary>
        public bool DeleteList(string IDlist)//IDlist指的是主键ID的名字，当为"ID"时删除整个表的数据，bll.DeleteList("ID");//删除整个表的数据
        {
            return dal.DeleteList(IDlist);
        }
        /// <summary>
        /// 得到一个对象实体
        /// </summary>
        public Model.UserInfo GetModel(int ID)
        {
            return dal.GetModel(ID);
        }
      
        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetList(string strWhere)
        {
            return dal.GetList(strWhere);
        }
        /// <summary>
        /// 获得数据列表_1
        /// </summary>
        public List<Model.UserInfo> GetModelList(string strWhere)
        {
            DataSet ds = dal.GetList(strWhere);
            return DataTableToList(ds.Tables[0]);
        }
        /// <summary>
        /// 获得数据列表_1_1
        /// </summary>
        public List<Model.UserInfo> DataTableToList(DataTable dt)
        {
            List<Model.UserInfo> modelList = new List<Model.UserInfo>();
            int rowsCount = dt.Rows.Count;
            if (rowsCount > 0)
            {
                Model.UserInfo model;
                for (int n = 0; n < rowsCount; n++)
                {
                    model = dal.DataRowToModel(dt.Rows[n]);
                    if (model != null)
                    {
                        modelList.Add(model);
                    }
                }
            }
            return modelList;
        }
        /// <summary>
        /// 获得数据列表
        /// </summary>
        public DataSet GetAllList()
        {
            return GetList("");
        }
        /// <summary>
        /// 获取记录总数
        /// </summary>
        public int GetRecordCount(string strWhere)
        {
            return dal.GetRecordCount(strWhere);
        }
        /// <summary>
        /// 分页获取数据列表
        /// </summary>
        public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
        {
            return dal.GetListByPage(strWhere, orderby, startIndex, endIndex);
        }
     
        #endregion  BasicMethod
        #region  ExtensionMethod
        #endregion  ExtensionMethod
    }
}
