﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Model
{
    /// <summary>
    /// UserInfo:实体类(属性说明自动提取数据库字段的描述信息)
    /// </summary>
    [Serializable]
    public partial class UserInfo
    {
        public UserInfo()
        { }
        #region Model
        private int _id;
        private string _zr1_Time1;
        private string _zr1_GroupID;
        private string _zr1_GroupName;//数字为 int?
        private string _zr1_QQID;
        private string _zr1_QQName;
        private string _zr1_Word;
       
        /// <summary>
        /// 数据该表的唯一ID编号
        /// </summary>
        public int ID
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 记录时间
        /// </summary>
        public string ZR1_Time1
        {
            set { _zr1_Time1 = value; }
            get { return _zr1_Time1; }
        }
        /// <summary>
        /// 群的ID号
        /// </summary>
        public string ZR1_GroupID
        {
            set { _zr1_GroupID = value; }
            get { return _zr1_GroupID; }
        }
        /// <summary>
        /// 群名字
        /// </summary>
        public string ZR1_GroupName
        {
            set { _zr1_GroupName = value; }
            get { return _zr1_GroupName; }
        }
        #endregion Model
        /// <summary>
        /// QQ的ID号
        /// </summary>
        public string ZR1_QQID
        {
            set { _zr1_QQID = value; }
            get { return _zr1_QQID; }
        }
        /// <summary>
        /// QQ的昵称
        /// </summary>
        public string ZR1_QQName
        {
            set { _zr1_QQName = value; }
            get { return _zr1_QQName; }
        }
        /// <summary>
        /// 发送文字
        /// </summary>
        public string ZR1_Word
        {
            set { _zr1_Word = value; }
            get { return _zr1_Word; }
        }
       
    }
}
