﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;//按钮反射
using System.Threading;
using System.Threading.Tasks;
namespace SQLiteDBTest
{
    public partial class Form1 : Form
    {
        public string _txtSearch1;
        public string TxtSearch1//文本框查找内容
        {
            set { _txtSearch1 = value; }
            get { return _txtSearch1; }
        }
        public int X_1 = 0;//要移动的单元格坐标X轴
        public int Y_1 = 0;//要移动的单元格坐标y轴
        public DataGridViewCell cell_1;//用于保存鼠标点击当前的单元格坐标变量
        public Form1()
        {
            InitializeComponent();
            DataSet ds = bll.GetAllList();
            this.dataGridView1.DataSource = ds.Tables[0];
        }
        BLL.UserInfo bll = new BLL.UserInfo();
        //数据库连接
        SQLiteConnection m_dbConnection;
        private void button1_Click(object sender, EventArgs e)//刷新
        {
            //刷新数据
            DataGridViewReset();
        }
        int count = 0;
        private void button2_Click(object sender, EventArgs e)//增加
        {
            //先保存坐标
            dataGridViewSvaeAddress();
            count++;
            Model.UserInfo userInfo = new Model.UserInfo();
            userInfo.ZR1_Time1 = this.textBox1.Text;
            userInfo.ZR1_GroupID = this.textBox2.Text;
            userInfo.ZR1_GroupName = this.textBox3.Text;
            userInfo.ZR1_QQID = this.textBox4.Text;
            userInfo.ZR1_QQName = this.textBox5.Text;
            userInfo.ZR1_Word = this.textBox6.Text;
            bll.Add(userInfo);
            //刷新数据
            DataGridViewReset();
            //回到以前坐标坐标
            DataGridViewSetBack();
        }
        private void button3_Click(object sender, EventArgs e)//修改
        {
            //先保存坐标
            dataGridViewSvaeAddress();
            //上传数据库后刷新dataGridView表格
            DataGridViewUpdate();
            //回到以前坐标
            DataGridViewSetBack();
        }
      
        private void button4_Click(object sender, EventArgs e)//删除
        {
            /*当读取的ID值最大为1时，说明该表除了字段名外没有了任何值，，点击表格会导致下面赋值的语句报错，
           以下所有语句都将不执行直接结束*/
            if (bll.GetMaxId() == 1)
            {
                return;
            }
            //先保存坐标
            dataGridViewSvaeAddress();
            //删除所选行
            // bll.Delete(int.Parse(this.textBox0.Text));
            DataGridViewRow row = this.dataGridView1.CurrentRow;
             if (row.Cells[0].Value.ToString()!="")
                        bll.Delete(int.Parse(row.Cells[0].Value.ToString())); 
            //刷新数据
       DataGridViewReset();
            //回到以前坐标
            DataGridViewSetBack();
        }
        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)//点击
        {
            // 把所选的行或者变化的行反应到功能按钮上面的textbox对应表格的窗口上
            DataGridViewChanged();
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("IExplore", "https://www.cnblogs.com/JiYF/p/11260178.html");
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Model.UserInfo userInfo = new Model.UserInfo();
            TxtSearch1 = this.txt_search.Text;
            if (bll.Exists_ZR1_XX1(TxtSearch1, "ZR1_GroupName") == true)
            {
                MessageBox.Show("找到相同内容");
            }
            else
            {
                MessageBox.Show("没找到相同内容");
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*  下拉列表combobox选择逻辑    */
            switch (comboBox1.SelectedItem.ToString()) //获取选择的内容
            {
                case "全部": MessageBox.Show("where " + "zr1_XXX" + "=@" + "zr1_XXX"); break;
                case "ID": MessageBox.Show("B"); break;
                case "时间": MessageBox.Show("C"); break;
                case "群号": MessageBox.Show("D"); break;
                case "群名": MessageBox.Show("E"); break;
                case "QQ号": MessageBox.Show("F"); break;
                case "QQ昵称": MessageBox.Show("G"); break;
                case "发送内容": MessageBox.Show("H"); break;
            }
        }
        /*  添加下拉列表的选项，USB选择列表 */
        public void Cbo_Box1Sel()
        {
            comboBox1.Items.Add("全部");
            comboBox1.Items.Add("ID");
            comboBox1.Items.Add("时间");
            comboBox1.Items.Add("群号");
            comboBox1.Items.Add("群名");
            comboBox1.Items.Add("QQ号");
            comboBox1.Items.Add("QQ昵称");
            comboBox1.Items.Add("发送内容");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Cbo_Box1Sel();
            // comboBox1.SelectedIndex = comboBox1.Items.IndexOf("群名");//combox默认显示哪一项内容
            //刷新数据
            DataGridViewReset();
        }
        private void btn_deletelist_Click(object sender, EventArgs e)//删除整个表
        {
            bll.DeleteList("ID");//删除整个表
            //刷新数据
            DataGridViewReset();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }
        private void textBox0_TextChanged(object sender, EventArgs e)
        {
        }
   /// <summary>
   /// 当单元格文字出现变化事件
   /// </summary>
   /// <param name="sender"></param>
   /// <param name="e"></param>
        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            // 把所选的行或者变化的行反应到功能按钮上面的textbox对应表格的窗口上
            DataGridViewChanged();
            //先保存坐标
            dataGridViewSvaeAddress();
            //上传数据库后刷新dataGridView表格
            DataGridViewUpdate();
            //回到以前坐标
            DataGridViewSetBack();
        }
      
        /// <summary>
        /// 记下当前单元格坐标，以便于刷新数据后重新回到此坐标
        /// </summary>
        public void dataGridViewSvaeAddress()
        {
            /*当读取的ID值最大为1时，说明该表除了字段名外没有了任何值，，点击表格会导致下面赋值的语句报错，
           以下所有语句都将不执行直接结束*/
            if (bll.GetMaxId() == 1)
            {
                return;
            }
            cell_1 = this.dataGridView1.CurrentCell;
            if (cell_1.ColumnIndex == 0 && cell_1.RowIndex == -1)
            {
            }
            else if (this.dataGridView1.CurrentCell.ColumnIndex == 0 && this.dataGridView1.CurrentCell.RowIndex == 0)
            {
            }
            else
            {
                X_1 = cell_1.ColumnIndex;
                Y_1 = cell_1.RowIndex;
            }
        }
        private void DataGridViewUpdate()
        {
            /*当读取的ID值最大为1时，说明该表除了字段名外没有了任何值，，点击表格会导致下面赋值的语句报错，
            以下所有语句都将不执行直接结束*/
            if (bll.GetMaxId() == 1)
            {
                return;
            }
            /*当ID为空的时候还强行转换就会报错，上传数据库会报错，以下所有语句都将不执行直接结束*/
            if (this.textBox0.Text == "")
            {
                return;
            }
            Model.UserInfo userInfo = new Model.UserInfo();
            userInfo.ID = int.Parse(this.textBox0.Text);
            userInfo.ZR1_Time1 = this.textBox1.Text;
            userInfo.ZR1_GroupID = this.textBox2.Text;
            userInfo.ZR1_GroupName = this.textBox3.Text;
            userInfo.ZR1_QQID = this.textBox4.Text;
            userInfo.ZR1_QQName = this.textBox5.Text;
            userInfo.ZR1_Word = this.textBox6.Text;
            bll.Update(userInfo);
            //刷新数据
          //  DataGridViewReset();
         
        }
        /// <summary>
        /// 把所选的行或者变化的行反应到功能按钮上面的textbox对应表格的窗口上
        /// </summary>
        private void DataGridViewChanged()
        {
            /*当读取的ID值最大为1时，说明该表除了字段名外没有了任何值，，点击表格会导致下面赋值的语句报错，
            以下所有语句都将不执行直接结束*/
            if (bll.GetMaxId() == 1)
            {
                return;
            }
            DataGridViewRow row = this.dataGridView1.CurrentRow;
            this.textBox0.Text = row.Cells[0].Value.ToString();
            this.textBox1.Text = row.Cells[1].Value.ToString();
            this.textBox2.Text = row.Cells[2].Value.ToString();
            this.textBox3.Text = row.Cells[3].Value.ToString();
            this.textBox4.Text = row.Cells[4].Value.ToString();
            this.textBox5.Text = row.Cells[5].Value.ToString();
            this.textBox6.Text = row.Cells[6].Value.ToString();
        }
        /// <summary>
        /// 刷新列表，导入数据库
        /// </summary>
        private void DataGridViewReset()
        {
           
            DataSet ds = bll.GetAllList();
            this.dataGridView1.DataSource = ds.Tables[0];
        }
     
        /// <summary>
        /// 回到指定坐标
        /// </summary>
        private void DataGridViewSetBack()
        {
            try
            {
                this.dataGridView1.CurrentCell = dataGridView1[X_1, Y_1];   //移动到指定单元格
            }
            catch
            {
                X_1 = 0;
                Y_1 = 0;
                this.dataGridView1.CurrentCell = dataGridView1[X_1, Y_1];   //移动到指定单元格
            }
        }
    }
}
