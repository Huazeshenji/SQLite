﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SQLiteDBTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        BLL.UserInfo bll = new BLL.UserInfo();
       

        //数据库连接
        SQLiteConnection m_dbConnection;
        private void button1_Click(object sender, EventArgs e)
        {

            DataSet ds =  bll.GetAllList();

            this.dataGridView1.DataSource = ds.Tables[0];

        }

        int count = 0;
        private void button2_Click(object sender, EventArgs e)
        {
            count++;
            Model.UserInfo userInfo = new Model.UserInfo();
            userInfo.ZR1_Time1 = this.textBox1.Text;
            userInfo.ZR1_GroupID = this.textBox2.Text;
            userInfo.ZR1_GroupName = this.textBox3.Text;
            userInfo.ZR1_QQID = this.textBox4.Text;
            userInfo.ZR1_QQName = this.textBox5.Text;
            userInfo.ZR1_Word = this.textBox6.Text;

            bll.Add(userInfo);
           

            DataSet ds = bll.GetAllList();
            this.dataGridView1.DataSource = ds.Tables[0];

        }

        private void button3_Click(object sender, EventArgs e)
        {

            Model.UserInfo userInfo = new Model.UserInfo();
            userInfo.ID = int.Parse(this.label1.Text);
            userInfo.ZR1_Time1 = this.textBox1.Text;
            userInfo.ZR1_GroupID = this.textBox2.Text;
            userInfo.ZR1_GroupName = this.textBox3.Text;
            userInfo.ZR1_QQID = this.textBox4.Text;
            userInfo.ZR1_QQName = this.textBox5.Text;
            userInfo.ZR1_Word = this.textBox6.Text;

            bll.Update(userInfo);


            DataSet ds = bll.GetAllList();
            this.dataGridView1.DataSource = ds.Tables[0];


        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            DataGridViewRow row = this.dataGridView1.CurrentRow;
            this.label1.Text = row.Cells[0].Value.ToString();
            this.textBox1.Text = row.Cells[1].Value.ToString();
            this.textBox2.Text = row.Cells[2].Value.ToString();
            this.textBox3.Text = row.Cells[3].Value.ToString();
            this.textBox4.Text = row.Cells[4].Value.ToString();
            this.textBox5.Text = row.Cells[5].Value.ToString();
            this.textBox6.Text = row.Cells[6].Value.ToString();


        }

        private void button4_Click(object sender, EventArgs e)
        {
            bll.Delete(int.Parse(this.label1.Text));


            DataSet ds = bll.GetAllList();
            this.dataGridView1.DataSource = ds.Tables[0];
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
         
            Process.Start("IExplore", "https://www.cnblogs.com/JiYF/p/11260178.html");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
          
            Model.UserInfo userInfo = new Model.UserInfo();
            userInfo.ID = int.Parse("60");
            bll.Exists(userInfo.ID);

            userInfo.ZR1_Time1 = "这是一个";

            bll.Exists_ZR1_Time1(userInfo.ZR1_Time1);

           


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
